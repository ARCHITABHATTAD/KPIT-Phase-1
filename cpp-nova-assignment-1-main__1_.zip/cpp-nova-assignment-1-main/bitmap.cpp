#include<iostream>
#include<cmath>
#include "bitmap.h"
using namespace std;

Complex::Complex()
{ 
    real=0;   
    img=0; 
}
	
Complex::Complex(int r, int i)
{
	int real=r;
   	int img=i;
}
	
void Complex::Accept()
{
	cout<<"Enter the complex number:"<<"\n";
   	cout<<"Real:";
   	cin>>real;
   	cout<<"Imaginary:";
   	cin>>img;
}

void Complex::Display()
{
	cout<<"complex number is:";
   	cout<<real<<"+"<<img<<"i"<<"\n";
}
	
Complex Complex::operator+(Complex &c)
{
	Complex temp;
	temp.real=temp.real+c.real;
   	temp.img=temp.img+c.img;
	return temp;
}
	
Complex Complex::operator-(Complex &c)
{
	Complex temp;
	temp.real=temp.real-c.real;
   	temp.img=temp.img-c.img;
	return temp;

}
Complex Complex::operator++()
{
	Complex temp;
	temp.real=++temp.real;
   	temp.img=++temp.img;
	return temp;
}
	
Complex Complex::operator++(int)
{
	Complex temp;
	temp.real=temp.real++;
   	temp.img=temp.img++;
	return temp;
}

bool Complex::operator==(Complex &c)
{
	bool flag=true;
	Complex temp;
	if(temp.real == c.real || temp.img == c.img)flag;
	else flag=false;
	return flag;
}
	
	
	
	
	
	
