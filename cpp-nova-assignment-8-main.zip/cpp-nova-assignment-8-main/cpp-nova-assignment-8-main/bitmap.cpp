#include<iostream>
#include"bitmap.h"
using namespace std;

template<typename T>
Queue<T>::Queue()
{
    size=5;
	front= -1; 
    rear = -1;
    arr =new T[size];
}

template<typename T>
Queue<T>::Queue(int s)
{
    size=s;
	front= -1;
    rear= -1;
	arr = new T[s];
}

template<typename T>
void Queue<T>::insert(T data)
{   
    if (isfull()) {  
      cout<<"Queue_Data_Structure is full";  
    } 
     if (front == -1) {  
        front = 0;  
    }  
    rear++;  
    arr[rear] = data; 
      
}
	
template<typename T>
T Queue<T>::remove()
{
    if(isempty())return 0;

    int data = arr[front];
    front = front + 1;
    return data;
}

	
template<typename T>
bool Queue<T>::isfull()
{
	 if (front == 0 && rear == size - 1) {  
      return true;  
    }  
    return false;
}
	
template<typename T>
bool Queue<T>::isempty()
{
	 if (front == -1)  
      return true;  
    else  
      return false;
}
