#include<iostream>
#include<cstring>
#include"bitmap.h"
using namespace std;

Account::Account()
{
	accno=0;
	char name=0;
	balance=0;
}


Account::Account(int acc, const char *n, double bal)
{
	int accno=acc;
	strcpy(name,n);
	double balance=bal;
}

void Account::accept()
{
	cout<<"\n Accout No. ";
    cin>>accno;
    cout<<"\n Name : ";
    cin>>name;
    cout<<"\n Balance : ";
    cin>>balance;
}


void Account::display()
{
    cout<<"\n Accout No. : "<<accno;
    cout<<"\n Name : "<<name;
    cout<<"\n Balance : "<<balance;  
}

void Account::deposite(int amount)
{
	balance+=amount;
}

void Account::withdraw(int amount)
{
	balance-=amount;
}

int Account::getAccno()
{
	return accno;
}
	
char* Account::getName()
{
	return name;
}

double Account::getBalance()
{
	return balance;
}

void Account::setAccno(int id)
{
	accno=id;
}

void Account::setName(const char *n)
{
	strcpy(name,n);
}

void Account::setBalance(double bal)
{
	balance=bal;
}

bool Account::searchAccountById(Account *accounts, int size, int id)
{
	bool status=false;
	for(int i=0;i<size;i++){
		if(accounts[i].accno==id){
            status=true;
            break;
        }
		else{
			status=false;
		}
	}
	return status;
}

double Account::getHighestBalance(Account *accounts, int size)
{
	int i, highestBal = accounts[0].balance;
	for(i=0;i<size;i++){
		if(accounts[i].balance > accounts[i+1].balance){
			highestBal= accounts[i].balance;
		}
	}
	return highestBal;
}


double Account::getLowestBalance(Account *accounts, int size)
{
	int i, lowestBal=accounts[0].balance;
	for(i=0;i<size;i++){
		if(accounts[i].balance < accounts[i+1].balance){
			lowestBal= accounts[i].balance;
		}
	}	
	return lowestBal;
}















