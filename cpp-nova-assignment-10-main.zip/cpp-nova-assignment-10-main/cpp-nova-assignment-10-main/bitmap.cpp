#include<iostream>
#include<cstring>
#include<algorithm>
#include"bitmap.h"
using namespace std;

Laptop::Laptop()
{
	lid=0;
	char make= 0;
	cost=0;
}

Laptop::Laptop(int id, const char *m, double c)
{
	lid=id;
	strcpy(make,m);
	cost=c;
}
	
int Laptop::GetLid()
{
	return lid;
}

char* Laptop::GetMake()
{
	return make;
}


double Laptop::GetCost()
{
	return cost;
}

void Laptop::Display()
{
	cout<<cost<<endl;
	cout<<make<<endl;
	cout<<lid<<endl;
}

void LaptopStore::InsertLaptop(Laptop l)
{
	vect_laptop.push_back(l);
}

bool compare(Laptop l1, Laptop l2)
{
	return l1.GetCost()<l2.GetCost();	
}

void LaptopStore::SortLaptops()
{
	std::sort(vect_laptop.begin(), vect_laptop.end(),compare);
}

vector<Laptop> LaptopStore::GetVect_Laptop()
{
	vector<Laptop>vec_tor = vect_laptop;
	return vec_tor;
}

Laptop LaptopStore::GetMinCostLaptop()
{
	return *std::min_element(vect_laptop.begin(), vect_laptop.end(),compare);
}

Laptop LaptopStore::GetMaxCostLaptop()
{
	return *std::max_element(vect_laptop.begin(), vect_laptop.end(),compare);
}
	
void LaptopStore::ShowLaptops()
{
	Laptop l;
	l.Display();
}




