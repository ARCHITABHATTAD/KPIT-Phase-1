#include<iostream>
#include"bitmap.h"
using namespace std;

template<typename T>
Stack<T>::Stack()
{
	size =5;
	top = -1;
	arr = new T[size];
}

template<typename T>
Stack<T>::Stack(int s)
{
    size=s;
    top = -1;
    arr = new T[s];
}

template<typename T>
void Stack<T>::push(T data)
{
    if (!isfull())
		arr[++top] = data;
}
	
template<typename T>
T Stack<T>::pop()
{
    if (!isempty())
		return arr[top--];
}

template<typename T>
T Stack<T>::peep()
{
    if (!isempty())
		return arr[top];
}
	
template<typename T>
bool Stack<T>::isfull()
{
    return ((top + 1) >= size);
}
	
template<typename T>
bool Stack<T>::isempty()
{
    return (top == -1);
}
